package com.example.drag1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class GetUserRegistered extends AppCompatActivity {

    private TextInputLayout first_name;
    private TextInputLayout last_name;
    private TextInputLayout age;
    private RadioGroup gender;
    private RadioButton check;
    private RadioButton male;
    private RadioButton female;
    private TextView error;
    private DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_user_registered);

        first_name = findViewById(R.id.text_first_name);
        last_name = findViewById(R.id.text_last_name);

        age = findViewById(R.id.text_age);
        gender = findViewById(R.id.gender);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        error = findViewById(R.id.gender_error);

        Button register = findViewById(R.id.button_register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validatename() | !validateage() | !validategender()){
                    return;
                }

                String uid = FirebaseAuth.getInstance().getUid();
                String path ="Users/"+uid;

                int radio_id = gender.getCheckedRadioButtonId();
                check = findViewById(radio_id);
                final String phonenumber = getIntent().getStringExtra("phonenumber");
                String sex = check.getText().toString();

                String first_ = first_name.getEditText().getText().toString();
                String last_ = last_name.getEditText().getText().toString();
                String fullname = first_ + " " + last_;
                String age__ = age.getEditText().getText().toString().trim();

                documentReference = FirebaseFirestore.getInstance().document(path);
                final Map<String, Object> user= new HashMap<String, Object>();
                user.put("name", fullname);
                user.put("sex",sex);
                user.put("age",age__);
                user.put("Phone_Number", phonenumber);
                documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        String uid = FirebaseAuth.getInstance().getUid();
                        final DocumentReference keydoc = FirebaseFirestore.getInstance().document("keys/"+uid);
                        keydoc.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                if(documentSnapshot.exists()){
                                    final Map<String, Object> users= new HashMap<String, Object>();
                                    users.put("key","1");
                                    keydoc.set(users).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Intent intent = new Intent(GetUserRegistered.this, Profile.class);
                                            startActivity(intent);
                                        }
                                    });
                                }
                            }
                        });

                    }
                });
            }
        });

    }
    public void checkButton(View v){
        int radio_id = gender.getCheckedRadioButtonId();
        check = findViewById(radio_id);

        Toast.makeText(this,check.getText(),Toast.LENGTH_SHORT).show();
    }

    private boolean validatename() {
        String first = first_name.getEditText().getText().toString().trim();
        String last = last_name.getEditText().getText().toString().trim();

        if(first.isEmpty() | last.isEmpty()) {
            if (first.isEmpty()) {
                first_name.setError("Field Can't be empty");
            }
            if (last.isEmpty()) {
                last_name.setError("Field Can't be empty");
            }
            return false;
        }
        else{
            first_name.setError(null);
            last_name.setError(null);
            return true;
        }
    }

    private  boolean validateage(){
        String age_ = age.getEditText().getText().toString().trim();
        int a = Integer.parseInt(age_);
        if(a<13 || a>60){
            age.setError("Enter A valid age Between 13 and 60");
            return false;
        }else{
            age.setError(null);
            return true;
        }
    }
    private boolean validategender(){
        if(male.isSelected() | female.isSelected()){
            error.setText(null);
            return true;
        }else{
            error.setText("Please Select your Gender");
            return true;
        }
    }

}
