package com.example.drag1;

public class CountryData {
    public static final String[] countryNames = {"India"};

    public static final String[] countryAreaCodes = {"91"};
}