package com.example.drag1;

import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class gymadapter extends RecyclerView.Adapter<gymadapter.MyViewHolder> {

    private int[] mDataset;
    private Context context;
    //private List<ClipData.Item> mDataset;
    // Provide a suitable constructor (depends on the kind of dataset)
    public gymadapter(int[] myDataset) {
        mDataset = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public gymadapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.gymitem,parent,false);
        return new MyViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        int image_id=mDataset[position];
        //ClipData.Item item=items.get(position);
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        //holder.postname.setText(postname);
        holder.posttImage.setImageResource(image_id);
        holder.postDescription.setText("mDataset :" +position);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.length;
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        ImageView posttImage;
        TextView postname;
        TextView postDescription;
        public MyViewHolder(View v) {
            super(v);
            posttImage=(ImageView) itemView.findViewById(R.id.image);
            postname=(TextView) itemView.findViewById(R.id.name);
            postDescription=(TextView) itemView.findViewById(R.id.description);

        }
    }
}
