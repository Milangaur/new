package com.example.drag1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class GetUserRegistered extends AppCompatActivity implements LocationListener{

    private TextInputLayout full_name;
    private TextInputLayout gym_name;
    private TextInputLayout email;
    private EditText pass;
    private RadioGroup gymtype;
    private RadioButton check;
    private RadioButton male;
    private RadioButton female;
    private TextView error;
    private DocumentReference documentReference;

    Button getLocationBtn;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_user_registered);

        full_name = findViewById(R.id.text_first_name);
        gym_name = findViewById(R.id.text_last_name);

        email = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        gymtype = findViewById(R.id.gymtype);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);

        getLocationBtn = (Button)findViewById(R.id.locationchoice);
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }

        getLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

        Button register = findViewById(R.id.button_register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validatename() | !validateage() | !validategender()){
                    return;
                }

                String uid = FirebaseAuth.getInstance().getUid();
                String path1 ="gymlocation/"+uid;
                String path2 ="gymprofile/"+uid;

                int radio_id = gymtype.getCheckedRadioButtonId();
                check = findViewById(radio_id);
                final String phonenumber = getIntent().getStringExtra("phonenumber");
                String sex = check.getText().toString();

                String owner = full_name.getEditText().getText().toString();
                String gymname = gym_name.getEditText().getText().toString();
                String email1= email.getEditText().getText().toString().trim();
                String pass1= pass.getText().toString().trim();

                documentReference = FirebaseFirestore.getInstance().document(path2);
                final Map<String, Object> user= new HashMap<String, Object>();
                user.put("Ownername", owner);
                user.put("Gym name", gymname);
                user.put("pass", pass1);
                user.put("Unisex",sex);
                user.put("Email",email1);
                user.put("Phone_Number", phonenumber);
                documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        String uid = FirebaseAuth.getInstance().getUid();
                        final DocumentReference keydoc = FirebaseFirestore.getInstance().document("profile/"+uid);
                        keydoc.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                if(documentSnapshot.exists()){
                                    final Map<String, Object> users= new HashMap<String, Object>();
                                    users.put("key","1");
                                    keydoc.set(users).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Intent intent = new Intent(GetUserRegistered.this, Profile.class);
                                            startActivity(intent);
                                        }
                                    });
                                }
                            }
                        });

                    }
                });
            }
        });

    }
    public void checkButton(View v){
        int radio_id = gender.getCheckedRadioButtonId();
        check = findViewById(radio_id);

        Toast.makeText(this,check.getText(),Toast.LENGTH_SHORT).show();
    }

    private boolean validatename() {
        String first = full_name.getEditText().getText().toString().trim();

        if(first.isEmpty()) {
            if (first.isEmpty()) {
                full_name.setError("Field Can't be empty");
            }
            return false;
        }
        else{
            first_name.setError(null);
            last_name.setError(null);
            return true;
        }
    }

    private  boolean validateage(){
        String age_ = age.getEditText().getText().toString().trim();
        int a = Integer.parseInt(age_);
        if(a<13 || a>60){
            age.setError("Enter A valid age Between 13 and 60");
            return false;
        }else{
            age.setError(null);
            return true;
        }
    }
    private boolean validategender(){
        if(male.isSelected() | female.isSelected()){
            error.setText(null);
            return true;
        }else{
            Toast.makeText(GetUserRegistered.this, "Please select gender", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    void getLocation() {
       try {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
        Toast.makeText(GetUserRegistered.this, "Location is set,Click register below", Toast.LENGTH_SHORT).show();
        // call GEOLOCATION

    }
        catch(SecurityException e) {
        e.printStackTrace();
            Toast.makeText(GetUserRegistered.this, "Coudn't lock location", Toast.LENGTH_SHORT).show();
    }
}

    @Override
    public void onLocationChanged(Location location) {
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);

            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    String uid = FirebaseAuth.getInstance().getUid();
                    final DocumentReference keydoc = FirebaseFirestore.getInstance().document("location/"+uid);
                    Keydoc.get().addOnSucessListener(new OnSuccessListener<DocumentSnapshot>() {
                                                         @Override
                                                         public void onSucess(DocumentSnapshot documentSnapshot) {
                                                             if(documentSnapshot.exists()){
                                                                 final Map<String,Object>
                                                             }
                                                         }
                                                     }

                    )

                }
            });
        }catch(Exception e)
        {

        }
    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(GetUserRegistered.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }
}
