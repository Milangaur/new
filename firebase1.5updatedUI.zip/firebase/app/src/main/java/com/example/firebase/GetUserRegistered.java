package com.example.firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GetUserRegistered extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_user_registered);
    }
}
